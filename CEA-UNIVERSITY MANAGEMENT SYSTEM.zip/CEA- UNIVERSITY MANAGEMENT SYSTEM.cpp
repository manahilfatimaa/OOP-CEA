#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
using namespace std;

fstream file1,file2,file3,file4;
int const size=5;	
class game{
private:
//global variables
char matrix[3][3] = { {'1', '2', '3'},{'4', '5', '6'} ,{'7', '8', '9' }};//decleration //char type matrix
char player = 'X';
public:
char getplayer(){
return player;
}
void Draw()
{cout<<" "<<endl;
	//pattren of displyed game board
    cout << "@--0--x--0--Tic Tac Toe--x--0--x---@ " << endl;
    cout<<" "<<endl;
    for (int i = 0; i < 3; i++)
    {	// rows
    cout<<"|-";
        for (int j = 0; j < 3; j++)
        {
        	//colums while rows being same and updation of colums for each row 
            cout<<matrix[i][j] << "-|-";
        }
        cout << endl; //one iritition completed
    }
    cout<<" "<<endl;
    //out of the loop
}

void posibility() //no return type no parameter
{
    int a;
    cout<<" "<<endl;
    cout <<"Press the number to input ur mark on it: ";
    cout<<" "<<endl;
    cin >> a; //from the user

    if (a == 1)
{
if(matrix[0][0]!='X'&&matrix[0][0]!='O')
{
matrix[0][0]=player;
}
else
{
cout<<"Try Again! in ur next turn because the box is already filled";
    }
   } else if (a == 2)
{
if(matrix[0][1]!='X'&&matrix[0][1]!='O')
{
matrix[0][1]=player;
}
else
{
cout<<"Try Again! in ur next turn because the box is already filled";
        
   } }else if (a == 3)
{
if(matrix[0][2]!='X'&&matrix[0][2]!='O')
{
matrix[0][2]=player;
}
else
{
cout<<"Try Again!in ur next turn because the box is already filled";
    }}else if (a == 4)
    
{
if(matrix[1][0]!='X'&&matrix[1][0]!='O')
{
matrix[1][0]=player;
}
else
{
cout<<"Try Again!in ur next turn because the box is already filled";
    }}else if (a == 5)
{
if(matrix[1][1]!='X'&&matrix[1][1]!='O')
{
matrix[1][1]=player;
}
else
{
cout<<"Try Again!in ur next turn because the box is already filled";

    }}else if (a == 6)
   
{
if(matrix[1][2]!='X'&&matrix[1][2]!='O')
{
matrix[1][2]=player;
}
else
{
cout<<"Try Again!in ur next turn because the box is already filled";
        
   }} else if (a == 7)
  
{
if(matrix[2][0]!='X'&&matrix[2][0]!='O')
{
matrix[2][0]=player;
}
else
{
cout<<"Try Again!in ur next turn because the box is already filled";
       
  }}  else if (a == 8)
    
{
if(matrix[2][1]!='X'&&matrix[2][1]!='O')
{
matrix[2][1]=player;
}
else
{
cout<<"Try Again!in ur next turn because the box is already filled";
        
  } } else if (a == 9)
   
{
if(matrix[2][2]!='X'&&matrix[2][2]!='O')
{
matrix[2][2]=player;
}
else
{
cout<<"Try Again!in ur next turn because the box is already filled";}      
   } else
    {
      cout<<"Not Valid Data :!!!"<<endl;
    }  
}
void Playerturn()
{
    if(player=='X')
    player='O';
    else
    player='X';
   
   
}
void clearboard()
{for (int i = 0; i < 3; i++) {
		for(int j=0;j<3;j++)
	cout<<	matrix[i][j];}
	}



char Win() //with return type and no parameter
{
    //first player
    if (matrix[0][0] == 'X' && matrix[0][1] == 'X' && matrix[0][2] == 'X')
        return 'X';
    if (matrix[1][0] == 'X' && matrix[1][1] == 'X' && matrix[1][2] == 'X')
        return 'X';
    if (matrix[2][0] == 'X' && matrix[2][1] == 'X' && matrix[2][2] == 'X')
        return 'X';
 
    if (matrix[0][0] == 'X' && matrix[1][0] == 'X' && matrix[2][0] == 'X')
        return 'X';
    if (matrix[0][1] == 'X' && matrix[1][1] == 'X' && matrix[2][1] == 'X')
        return 'X';
    if (matrix[0][2] == 'X' && matrix[1][2] == 'X' && matrix[2][2] == 'X')
        return 'X';
 
    if (matrix[0][0] == 'X' && matrix[1][1] == 'X' && matrix[2][2] == 'X')
        return 'X';
    if (matrix[2][0] == 'X' && matrix[1][1] == 'X' && matrix[0][2] == 'X')
        return 'X';
 
    //second player
    if (matrix[0][0] == 'O' && matrix[0][1] == 'O' && matrix[0][2] == 'O')
        return 'O';
    if (matrix[1][0] == 'O' && matrix[1][1] == 'O' && matrix[1][2] == 'O')
        return 'O';
    if (matrix[2][0] == 'O' && matrix[2][1] == 'O' && matrix[2][2] == 'O')
        return 'O';
 
    if (matrix[0][0] == 'O' && matrix[1][0] == 'O' && matrix[2][0] == 'O')
        return 'O';
    if (matrix[0][1] == 'O' && matrix[1][1] == 'O' && matrix[2][1] == 'O')
        return 'O';
    if (matrix[0][2] == 'O' && matrix[1][2] == 'O' && matrix[2][2] == 'O')
        return 'O';
 
    if (matrix[0][0] == 'O' && matrix[1][1] == 'O' && matrix[2][2] == 'O')
        return 'O';
    if (matrix[2][0] == 'O' && matrix[1][1] == 'O' && matrix[0][2] == 'O')
        return 'O';
        
    return '*';
}
void redraw(){
	cout<<" "<<endl;
	//pattren of displyed game board
    cout << "@--0--x--0--Tic Tac Toe--x--0--x---@ " << endl;
    cout<<" "<<endl;
    for (int i = 0; i < 3; i++)
    {	// rows
    cout<<"|-";
        for (int j = 0; j < 3; j++)
        {
        	//colums while rows being same and updation of colums for each row 
            cout<<matrix[i][j] << "-|-";
        }
        cout << endl; //one iritition completed
    }
    cout<<" "<<endl;
}
void resetGame() {
	for (int i = 0; i < 3; i++) {
		for(int j=0;j<3;j++)
		matrix[i][j] = 0;}
	}

};
class Cafe
{
    private:
    int billmoney=0;
    char option1;
    int option;
    char o;
		public:
    void menu() {
    	cout<<"*****************************"<<endl;
    	cout << "   MAIN COURSE"<<endl;
    	cout<<"*****************************"<<endl;
    	cout << "1. CHICKEN CHEESE BURGER - Rs 350" <<endl;
    	cout << "2. CHICKEN CHEESE BALLS - Rs 600" <<endl;
    	cout << "3. CHICKEN NOODLES - Rs 400" <<endl;
    	cout << "4. CHICKEN FRIED RICE - Rs 800" <<endl;
    	cout << "5. VEGETABLE FRIED RICE - Rs 500" <<endl;
    	cout << "6. MASALA RICE - Rs 700" <<endl;
    	cout << endl;
    	cout<<"*****************************"<<endl;
    	cout << "    DRINKS"<<endl;
    	cout<<"*****************************"<<endl;
    	cout << "7. ICED COFFEE - Rs 500" <<endl;
    	cout << "8. APPLE JUICE - Rs 250" <<endl;
    	cout << "9. MANGO SHAKE - Rs 400" <<endl;
    	cout << "10. STRAWBERRY SLUSH - Rs 500" <<endl;
    	cout << endl;
    	cout<<"*****************************"<<endl;
    	cout << " SIDES AND APPETIZERS" <<endl;
    	cout<<"*****************************"<<endl;
    	cout << "11. FRUIT SALAD - Rs 300" <<endl;
    	cout << "12. VEGETABLE SALAD - Rs 200" <<endl;
    	cout << "13. FRIED ONIONS - Rs 350" <<endl;
    	cout << "14. BEEF SAUSAGES - Rs 1000" <<endl;
    	cout << "15. CHIPS - Rs 300" <<endl;
	}	
	void select(){
		
		cout<<"pess y to buy or press n to show bill";
		cin>>option1;
		if(option='y')
		buy();
		if(option='n')
		showbill();
	}
	void buy()
	{
	    cout << "MAIN COURSE"<<endl;
    	cout << "1. CHICKEN CHEESE BURGER - Rs 350" <<endl;
    	cout << "2. CHICKEN CHEESE BALLS - Rs 600" <<endl;
    	cout << "3. CHICKEN NOODLES - Rs 400" <<endl;
    	cout << "4. CHICKEN FRIED RICE - Rs 800" <<endl;
    	cout << "5. VEGETABLE FRIED RICE - Rs 500" <<endl;
    	cout << "6. MASALA RICE - Rs 700" <<endl;
    	cout << endl;
    	cout << "DRINKS"<<endl;
    	cout << "7. ICED COFFEE - Rs 500" <<endl;
    	cout << "8. APPLE JUICE - Rs 250" <<endl;
    	cout << "9. MANGO SHAKE - Rs 400" <<endl;
    	cout << "10. STRAWBERRY SLUSH - Rs 500" <<endl;
    	cout << endl;
    	cout << "SIDES AND APPETIZERS" <<endl;
    	cout << "11. FRUIT SALAD - Rs 300" <<endl;
    	cout << "12. VEGETABLE SALAD - Rs 200" <<endl;
    	cout << "13. FRIED ONIONS - Rs 350" <<endl;
    	cout << "14. BEEF SAUSAGES - Rs 1000" <<endl;
    	cout << "15. CHIPS - Rs 300" <<endl;
	   b:
	   cout<<"enter value: ";
	   cin>>option;
				if (option ==1 )
        {
        	cout << "CHICKEN CHEESE BURGER DELIVERED "<<endl;
        	billmoney = 350 + billmoney;
        	cout<<"if you want to add more press x else press any key";
        	cin>>o;
        	if(o=='x')
        	goto b;
				}
				if (option ==2 )
        {
        	cout << "CHICKEN CHEESE BALLS  DELIVERED "<<endl;
        	billmoney = 600 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        		if(o=='x')
        	goto b;
				}
				if (option ==3 )
        {
        	cout << "CHICKEN NOODLES DELIVERED "<<endl;
        	billmoney = 400 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        		if(o=='x')
        	goto b;
				}
				if (option ==4 )
        {
        	cout << "CHICKEN FRIED RICE DELIVERED "<<endl;
        	billmoney = 800 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        		if(o=='x')
        	goto b;
				}
				if (option ==5 )
        {
        	cout << "VEGETABLE FRIED RICE DELIVERED "<<endl;
        	billmoney = 500 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        		if(o=='x')
        	goto b;
				}
				if (option ==6 )
        {
        	cout << "MASALA RICE DELIVERED "<<endl;
        	billmoney = 700 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        	if(o=='x')
        	goto b;
				}
				if (option ==7 )
        {
        	cout << "ICED COFFEE  DELIVERED "<<endl;
        	billmoney = 500 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        		if(o=='x')
        	goto b;
				}
				if (option ==8 )
        {
        	cout << "APPLE JUICE DELIVERED "<<endl;
        	billmoney = 250 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        		if(o=='x')
        	goto b;
				}
				if (option ==9 )
        {
        	cout << "MANGO SHAKE DELIVERED "<<endl;
        	billmoney = 400 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        		if(o=='x')
        	goto b;
				}
				if (option ==10 )
        {
        	cout << "STRAWBERRY SLUSH DELIVERED "<<endl;
        	billmoney = 500 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        	if(o=='x')
        	goto b;
				}
				if (option ==11 )
        {
        	cout << "FRUIT SALAD DELIVERED "<<endl;
        	billmoney = 300 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        		if(o=='x')
        	goto b;
				}
				if (option ==12 )
        {
        	cout << "VEGETABLE SALAD DELIVERED "<<endl;
        	billmoney = 200 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        	if(o=='x')
        	goto b;
				}
				if (option ==13 )
        {
        	cout << "FRIED ONIONS DELIVERED "<<endl;
        	billmoney = 350 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        	if(o=='x')
        	goto b;
				}
				if (option ==14 )
        {
        	cout << "BEEF SAUSAGES DELIVERED "<<endl;
        	billmoney = 1000 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        	if(o=='x')
        	goto b;
				}	    
				if (option ==15 )
        {
        	cout << " CHIPS DELIVERED "<<endl;
        	billmoney = 300 + billmoney;
        		cout<<"if you want to add more press x else press any key";
        	cin>>o;
        	if(o=='x')
        	goto b;
				}
}
	void showbill()
	{
	    
	    cout<<"****your bill is****:"<<billmoney;
	    
	    }
}a;
class teacherportal
{
protected:
int classnum=4;	
int option,option2,option3,option4;
string name[size];
int rollnum[size];
float lab1perf[size];
float lab2perf[size];
float lab3perf[size];
float lab4perf[size];
float lab5perf[size];
float lab6perf[size];
float lab7perf[size];
float lab8perf[size];
float lab9perf[size];
float lab10perf[size];
float lab1rep[size];
float lab2rep[size];
float lab3rep[size];
float lab4rep[size];
float lab5rep[size];
float lab6rep[size];
float lab7rep[size];
float lab8rep[size];
float mids[size];
float CEA[size];
float final[size];
float total_labperf[size];
float total_labrep[size];	
float weigh_labperf;
float weigh_labrep;
float weigh_mids;
float weigh_final;
float weigh_CEA;
float total_marks[size];
char grade[size];

public:
 teacherportal()
 {
weigh_labperf=10;
weigh_labrep=5;
weigh_mids=25;
weigh_final=35;
weigh_CEA=25;
	}   
};

class MTSB : public teacherportal
{
	
public:
	
void data_mtsb_entery()
{
cout<<"Enter data in this sequence, Roll no. , Name , Labperformence , labreport , mid-term and finals : "<<endl;	
file1.open("CE-112L MTS II B.cvs",ios::out | ios::app);	
 for (int i = 0; i < size; i++)
    {
        cout<<"Enter Student "<<i+1<<" data"<<endl;
        cout<<"Roll number: ";
        cin>>rollnum[i];
        cout<<"Name: ";
        cin>>name[i];
        cout<<"assesment marks"<<endl;
		cout<<"Press 1 for lab performance"<<endl;
		cout<<"Press 2 for lab lab report"<<endl;
		cout<<"press 3 for Midterm"<<endl;
		cout<<"press 4 for CEA"<<endl;
		cout<<"press 5 for Final term"<<endl;
		cin>>option2;  
		switch(option2)
		{
			case 1:
				{int j=0;
				while (j<5)
				{
				cout<<"Press 1 for lab 1 performance"<<endl;
				cout<<"Press 2 for lab 2 performance"<<endl;
				cout<<"Press 3 for lab 3 performance"<<endl;	
				cout<<"Press 4 for lab 4 performance"<<endl;
				cout<<"Press 5 for lab 5 performance"<<endl;
				cout<<"Press 6 for lab 6 performance"<<endl;
				cout<<"Press 7 for lab 7 performance"<<endl;
				cout<<"Press 8 for lab 8 performance"<<endl;
				cout<<"Press 9 for lab 9 performance"<<endl;
				cout<<"Press 10 for lab 10 performance"<<endl;	
				cin>>option3;	
				switch(option3)
			   {
				 case 1:
				        cin>>lab1perf[i];
				        break;
				case 2:
				        cin>>lab2perf[i];
				        break;
				case 3:
				        cin>>lab3perf[i];  
						break;      
				case 4:
				        cin>>lab4perf[i];
				        break;
				case 5:
				        cin>>lab5perf[i];
				        break;
				case 6:
				        cin>>lab6perf[i];
				        break;
				case 7:
				        cin>>lab7perf[i];
				        break;
				case 8:
				        cin>>lab8perf[i];
				        break;
				case 9:
				        cin>>lab9perf[i];
				        break;
				case 10:
				        cin>>lab10perf[i];
						break; }	j++;}}			
						
			case 2:
			   { int j=0;
				while (j<5)
				{
				cout<<"Press 1 for lab 1 report"<<endl;
				cout<<"Press 2 for lab 2 report"<<endl;
				cout<<"Press 3 for lab 3 report"<<endl;	
				cout<<"Press 4 for lab 4 report"<<endl;
				cout<<"Press 5 for lab 5 report"<<endl;		
				cin>>option4;
				switch(option4)
				{
					case 1:
				        cin>>lab1rep[i];
				        break;
				case 2:
				        cin>>lab2rep[i];
				        break;
				case 3:
				        cin>>lab3rep[i]; 
						break;       
				case 4:
				        cin>>lab4rep[i];
				        break;
				case 5:
				        cin>>lab5rep[i];
				        break;
					
						}		
			j++;}}
			case 3:
				{
					cout<<"Enter mids marks :"<<endl;
					cin>>mids[i];
					break;
				}
			case 4:
			{
				cout<<"Enter final marks :"<<endl;
				cin>>final[i];
				break;
						}
			case 5:
			{
				cout<<"Enter CEA marks : "<<endl;
				cin>>CEA[i];
				break;
									}						
	 }                                  
    }
 	  file1<<"rollnum"<<","<<"name"<<","
         <<"lab1perf"<<","<<"lab2perf"<<","<<"lab3perf"<<","<<"lab4perf"<<","<<"lab5perf"<<","<<"lab6perf"<<","<<"lab7perf"<<","<<"lab8perf"<<","<<"lab9perf"<<","<<"lab10perf"<<","
         <<"lab1rep"<<","<<"lab2rep"<<","<<"lab3rep"<<","<<"lab4rep"<<","<<"lab5rep"<<","
         <<"mids"<<","
         <<"CEA"<<","
         <<"final"<<","<<"grades"<<"\n";  
			for(int j=0;j<size;j++)
	{
	file1.open("CE-112L MTS II B.cvs",ios::out)	;
	file1<<rollnum[j]<<","<<name[j]<<","
         <<lab1perf[j]<<","<<lab2perf[j]<<","<<lab3perf[j]<<","<<lab4perf[j]<<","<<lab5perf[j]<<","<<lab6perf[j]<<","<<lab7perf[j]<<","<<lab8perf[j]<<","
         <<lab9perf[j]<<","<<lab10perf[j]<<","
         <<lab1rep[j]<<","<<lab2rep[j]<<","<<lab3rep[j]<<","<<lab4rep[j]<<","<<lab5rep[j]<<","
         <<mids[j]<<","
         <<CEA[j]<<","
         <<final[j]<<","<<grade[j]<<"\n";	
	} 
}

void data_mtsb_read()
{
string line;
file1.open("CE-112L MTS II B.cvs",ios::in);
int i=0;
while (getline(file1, line)) 
{
    string rand;
    istringstream iss(line); 
    iss >> rollnum[i];
    getline(iss, rand, ',');
    getline(iss, name[i], ',');
    iss >> lab1perf[i];
    getline(iss, rand, ',');
    iss >> lab2perf[i];
    getline(iss, rand, ',');
    iss >> lab3perf[i];
    getline(iss, rand, ',');
    iss >> lab4perf[i];
    getline(iss, rand, ',');
    iss >> lab5perf[i];
    getline(iss, rand, ',');
    iss >> lab6perf[i];
    getline(iss, rand, ',');
    iss >> lab7perf[i];
    getline(iss, rand, ',');
    iss >> lab8perf[i];
    getline(iss, rand, ',');
    iss >> lab9perf[i];
    getline(iss, rand, ',');
    iss >> lab10perf[i];
    getline(iss, rand, ',');
    iss >>  lab1rep[i];
    getline(iss, rand, ',');
	iss >>  lab2rep[i];
	getline(iss, rand, ',');
	iss >>  lab3rep[i];
	getline(iss, rand, ',');
	iss >>  lab4rep[i];
	getline(iss, rand, ',');
	iss >>  lab5rep[i];   
	getline(iss, rand, ',');
	iss >>  mids[i];
	getline(iss, rand, ',');
	iss >>  final[i];
	getline(iss, rand, ',');
	iss >>  CEA[i];	 
    i++;
}
}

void set_mtsb_weightages()
{
	float total_weigh=100;
	float weigh;
	cout<<"Enter lab performance weightage : ";
	cin>>weigh_labperf;
	cout<<"Enter lab reports weightage : ";
	cin>>weigh_labrep;
	cout<<"Enter mids weightage : ";
	cin>>weigh_mids;
	cout<<"Enter finals weightage : ";
	cin>>weigh_final;
	cout<<"Enter CEA weightage : ";
	cin>>weigh_CEA;	
	weigh=weigh_labperf+weigh_labrep+weigh_mids+weigh_final+weigh_CEA;
	if (total_weigh==weigh)
	{
	cout<<"sum of total weightage : "<<weigh<<endl;
	}		
	else
	cout<<"Entered weightages are in correct"<<endl;
}

void mtsb_total_marks()
{	
for(int i=0; i<size ;i++)
{
total_labperf[i]=lab1perf[i]+lab2perf[i]+lab3perf[i]+lab4perf[i]+lab5perf[i]+lab6perf[i]+lab7perf[i]+lab8perf[i]+lab9perf[i]+lab10perf[i];
total_labrep[i]=lab1rep[i]+lab2rep[i]+lab3rep[i]+lab5rep[i]+lab5rep[i];	
}
for(int j=0;j<size;j++)
{
total_marks[j]=((weigh_labperf*total_labperf[j])+(weigh_labrep*total_labrep[j])+(weigh_mids*mids[j])+(weigh_final*final[j])+(weigh_CEA*CEA[j]));
cout<<"total marks : "<<total_marks[j]<<endl;
}
}

void mtsb_grades()
{
	for(int i=0;i<5;i++)
	{
		if(total_marks[i]>=140 )
		{
		grade[i]='A';	
		}
		if(total_marks[i]<140&&total_marks[i]>=100)
		{
		grade[i]='B';	
		}
		if(total_marks[i]<100&&total_marks[i]>=80)
		{
		grade[i]='C';	
		}
		if(total_marks[i]<80&&total_marks[i]>=55)
		{
		grade[i]='D';	
		}
		if(total_marks[i]<55&&total_marks[i]>=45)
		{
		grade[i]='E';	
		}
		if(total_marks[i]<45)
		{
		grade[i]='F';	
		}
		  cout<<"grade : "<<grade[i]<<endl;
	}
	
			for(int j=0;j<size;j++)
	{
	file1.open("CE-112L MTS II B.cvs",ios::out)	;
	file1<<rollnum[j]<<","<<name[j]<<","
         <<lab1perf[j]<<","<<lab2perf[j]<<","<<lab3perf[j]<<","<<lab4perf[j]<<","<<lab5perf[j]<<","<<lab6perf[j]<<","<<lab7perf[j]<<","<<lab8perf[j]<<","
         <<lab9perf[j]<<","<<lab10perf[j]<<","
         <<lab1rep[j]<<","<<lab2rep[j]<<","<<lab3rep[j]<<","<<lab4rep[j]<<","<<lab5rep[j]<<","
         <<mids[j]<<","
         <<CEA[j]<<","
         <<final[j]<<","<<grade[j]<<"\n";	
	}
}

};

class MTSA : public teacherportal
{
	
public:
void data_mtsa_entery(){
cout<<"Enter data in this sequence, Roll no. , Name , Labperformence , labreport , mid-term and finals : "<<endl;	
file2.open("CE-112L MTS II-A.csv",ios::out | ios::app);	
 for (int i = 0; i < size; i++)
    {
        cout<<"Enter Student "<<i+1<<" data"<<endl;
        cout<<"Roll number: ";
        cin>>rollnum[i];
        cout<<"Name: ";
        cin>>name[i];
        cout<<"assesment marks"<<endl;
		cout<<"Press 1 for lab performance"<<endl;
		cout<<"Press 2 for lab lab report"<<endl;
		cout<<"press 3 for Midterm"<<endl;
		cout<<"press 4 for CEA"<<endl;
		cout<<"press 5 for Final term"<<endl;
		cin>>option2;  
		switch(option2)
		{
			case 1:
				{int j=0;
				while (j<10)
				{
				cout<<"Press 1 for lab 1 performance"<<endl;
				cout<<"Press 2 for lab 2 performance"<<endl;
				cout<<"Press 3 for lab 3 performance"<<endl;	
				cout<<"Press 4 for lab 4 performance"<<endl;
				cout<<"Press 5 for lab 5 performance"<<endl;
				cout<<"Press 6 for lab 6 performance"<<endl;
				cout<<"Press 7 for lab 7 performance"<<endl;
				cout<<"Press 8 for lab 8 performance"<<endl;
				cout<<"Press 9 for lab 9 performance"<<endl;
				cout<<"Press 10 for lab 10 performance"<<endl;	
				cin>>option3;	
				switch(option3)
			   {
				 case 1:
				        cin>>lab1perf[i];
				        break;
				case 2:
				        cin>>lab2perf[i];
				        break;
				case 3:
				        cin>>lab3perf[i];  
						break;      
				case 4:
				        cin>>lab4perf[i];
				        break;
				case 5:
				        cin>>lab5perf[i];
				        break;
				case 6:
				        cin>>lab6perf[i];
				        break;
				case 7:
				        cin>>lab7perf[i];
				        break;
				case 8:
				        cin>>lab8perf[i];
				        break;
				case 9:
				        cin>>lab9perf[i];
				        break;
				case 10:
				        cin>>lab10perf[i];
						break; }	j++;}}			
						
			case 2:
			   { 	int j=0;
				while (j<5)
				{
				cout<<"Press 1 for lab 1 report"<<endl;
				cout<<"Press 2 for lab 2 report"<<endl;
				cout<<"Press 3 for lab 3 report"<<endl;	
				cout<<"Press 4 for lab 4 report"<<endl;
				cout<<"Press 5 for lab 5 report"<<endl;		
				cin>>option4;
				switch(option4)
				{
					case 1:
				        cin>>lab1rep[i];
				        break;
				case 2:
				        cin>>lab2rep[i];
				        break;
				case 3:
				        cin>>lab3rep[i]; 
						break;       
				case 4:
				        cin>>lab4rep[i];
				        break;
				case 5:
				        cin>>lab5rep[i];
				        break;
					
						}		
			j++;}}
			case 3:
				{
					cout<<"Enter mids marks :"<<endl;
					cin>>mids[i];
					break;
				}
			case 4:
			{
				cout<<"Enter final marks :"<<endl;
				cin>>final[i];
				break;
						}
			case 5:
			{
				cout<<"Enter CEA marks : "<<endl;
				cin>>CEA[i];
				break;
									}						
	 }  
	
	} 
	  file2<<"rollnum"<<","<<"name"<<","
          <<"lab1perf"<<","<<"lab2perf"<<","<<"lab3perf"<<","<<"lab4perf"<<","<<"lab5perf"<<","<<"lab6perf"<<","<<"lab7perf"<<","<<"lab8perf"<<","<<"lab9perf"<<","<<"lab10perf"<<","
         <<"lab1rep"<<","<<"lab2rep"<<","<<"lab3rep"<<","<<"lab4rep"<<","<<"lab5rep"<<","
         <<"mids"<<","
         <<"CEA"<<","
         <<"final"<<","<<"grades"<<"\n";  
		for(int j=0;j<size;j++)
	{
	file2.open("CE-112L MTS II-A.csv",ios::out)	;
	file2<<rollnum[j]<<","<<name[j]<<","
         <<lab1perf[j]<<","<<lab2perf[j]<<","<<lab3perf[j]<<","<<lab4perf[j]<<","<<lab5perf[j]<<","<<lab6perf[j]<<","<<lab7perf[j]<<","<<lab8perf[j]<<","
         <<lab9perf[j]<<","<<lab10perf[j]<<","
         <<lab1rep[j]<<","<<lab2rep[j]<<","<<lab3rep[j]<<","<<lab4rep[j]<<","<<lab5rep[j]<<","
         <<mids[j]<<","
         <<CEA[j]<<","
         <<final[j]<<","<<grade[j]<<"\n"; 
}                                 
    }
  	

void data_mtsa_read()
{
string line;
file2.open("CE-112L MTS II-A.csv",ios::in);
int i=0;
while (getline(file2, line)) 
{
    string rand;
    istringstream iss(line); 
    iss >> rollnum[i];
    getline(iss, rand, ',');
    getline(iss, name[i], ',');
    iss >> lab1perf[i];
    getline(iss, rand, ',');
    iss >> lab2perf[i];
    getline(iss, rand, ',');
    iss >> lab3perf[i];
    getline(iss, rand, ',');
    iss >> lab4perf[i];
    getline(iss, rand, ',');
    iss >> lab5perf[i];
    getline(iss, rand, ',');
    iss >> lab6perf[i];
    getline(iss, rand, ',');
    iss >> lab7perf[i];
    getline(iss, rand, ',');
    iss >> lab8perf[i];
    getline(iss, rand, ',');
    iss >> lab9perf[i];
    getline(iss, rand, ',');
    iss >> lab10perf[i];
    getline(iss, rand, ',');
    iss >>  lab1rep[i];
    getline(iss, rand, ',');
	iss >>  lab2rep[i];
	getline(iss, rand, ',');
	iss >>  lab3rep[i];
	getline(iss, rand, ',');
	iss >>  lab4rep[i];
	getline(iss, rand, ',');
	iss >>  lab5rep[i];
	getline(iss, rand, ',');
	iss >>  mids[i];
	getline(iss, rand, ',');
	iss >>  final[i];
	getline(iss, rand, ',');
	iss >>  CEA[i];		    
    i++;
}
}

void set_mtsa_weightages()
{
	float total_weigh=100;
	float weigh;
	cout<<"Enter lab performance weightage : ";
	cin>>weigh_labperf;
	cout<<"Enter lab reports weightage : ";
	cin>>weigh_labrep;
	cout<<"Enter mids weightage : ";
	cin>>weigh_mids;
	cout<<"Enter finals weightage : ";
	cin>>weigh_final;
	cout<<"Enter CEA weightage : ";
	cin>>weigh_CEA;	
	weigh=weigh_labperf+weigh_labrep+weigh_mids+weigh_final+weigh_CEA;
	if (total_weigh==weigh)
	{
	cout<<"sum of total weightage : "<<weigh<<endl;
	}		
	else
	cout<<"Entered weightages are in correct"<<endl;			
}

void mtsa_total_marks()
{	
for(int i=0; i<=size ;i++)
{
total_labperf[i]=lab1perf[i]+lab2perf[i]+lab3perf[i]+lab4perf[i]+lab5perf[i]+lab6perf[i]+lab7perf[i]+lab8perf[i]+lab9perf[i]+lab10perf[i];
total_labrep[i]=lab1rep[i]+lab2rep[i]+lab3rep[i]+lab5rep[i]+lab5rep[i];	
}
for(int j=0;j<size;j++)
{
total_marks[j]=((weigh_labperf*total_labperf[j])+(weigh_labrep*total_labrep[j])+(weigh_mids*mids[j])+(weigh_final*final[j])+(weigh_CEA*CEA[j]));
cout<<"total marks : "<<total_marks[j]<<endl;
}
}

void mtsa_grades()
{
	for(int i=0;i<size;i++)
	{
		if(total_marks[i]>=140 )
		{
		grade[i]='A';	
		}
		if(total_marks[i]<140&&total_marks[i]>=100)
		{
		grade[i]='B';	
		}
		if(total_marks[i]<100&&total_marks[i]>=80)
		{
		grade[i]='C';	
		}
		if(total_marks[i]<80&&total_marks[i]>=55)
		{
		grade[i]='D';	
		}
		if(total_marks[i]<55&&total_marks[i]>=45)
		{
		grade[i]='E';	
		}
		if(total_marks[i]<45)
		{
		grade[i]='F';	
		}
		  cout<<"grade : "<<grade[i]<<endl;
	}
	
		for(int j=0;j<size;j++)
	{
	file2.open("CE-112L MTS II-A.csv",ios::out)	;
	file2<<rollnum[j]<<","<<name[j]<<","
         <<lab1perf[j]<<","<<lab2perf[j]<<","<<lab3perf[j]<<","<<lab4perf[j]<<","<<lab5perf[j]<<","<<lab6perf[j]<<","<<lab7perf[j]<<","<<lab8perf[j]<<","
         <<lab9perf[j]<<","<<lab10perf[j]<<","
         <<lab1rep[j]<<","<<lab2rep[j]<<","<<lab3rep[j]<<","<<lab4rep[j]<<","<<lab5rep[j]<<","
         <<mids[j]<<","
         <<CEA[j]<<","
         <<final[j]<<","<<grade[j]<<"\n";	
	}
}

};

class BEEP : public teacherportal
{
	
public:
void data_beep_entery()
{
cout<<"Enter data in this sequence, Roll no. , Name , Labperformence , labreport , mid-term and finals : "<<endl;	
file3.open("CE-112L BEEP II-A.csv",ios::out | ios::app);	
 for (int i = 0; i < size; i++)
    {
        cout<<"Enter Student "<<i+1<<" data"<<endl;
        cout<<"Roll number: ";
        cin>>rollnum[i];
        cout<<"Name: ";
        cin>>name[i];
        cout<<"assesment marks"<<endl;
		cout<<"Press 1 for lab performance / 15"<<endl;
		cout<<"Press 2 for lab lab report /15"<<endl;
		cout<<"press 3 for Midterm /55"<<endl;
		cout<<"press 4 for CEA /20"<<endl;
		cout<<"press 5 for Final term /50"<<endl;
		cin>>option2;  
		switch(option2)
		{
			case 1:
				{int j=0;
				while (j<8)
				{
				cout<<"Press 1 for lab 1 performance"<<endl;
				cout<<"Press 2 for lab 2 performance"<<endl;
				cout<<"Press 3 for lab 3 performance"<<endl;	
				cout<<"Press 4 for lab 4 performance"<<endl;
				cout<<"Press 5 for lab 5 performance"<<endl;
				cout<<"Press 6 for lab 6 performance"<<endl;
				cout<<"Press 7 for lab 7 performance"<<endl;
				cout<<"Press 8 for lab 8 performance"<<endl;	
				cin>>option3;	
				switch(option3)
			   {
				 case 1:
				 	cout<<endl;
				        cin>>lab1perf[i];
				        break;
				case 2:
					cout<<endl;
				        cin>>lab2perf[i];
				        break;
				case 3:
					cout<<endl;
				        cin>>lab3perf[i];  
						break;      
				case 4:
					cout<<endl;
				        cin>>lab4perf[i];
				        break;
				case 5:
					cout<<endl;
				        cin>>lab5perf[i];
				        break;
				case 6:
					cout<<endl;
				        cin>>lab6perf[i];
				        break;
				case 7:
					cout<<endl;
				        cin>>lab7perf[i];
				        break;
				case 8:
					cout<<endl;
				        cin>>lab8perf[i];
				        break; } j++;	}}			
						
			case 2:
			   { int j=0;
				while (j<8)
				{
				cout<<"Press 1 for lab 1 report"<<endl;
				cout<<"Press 2 for lab 2 report"<<endl;
				cout<<"Press 3 for lab 3 report"<<endl;	
				cout<<"Press 4 for lab 4 report"<<endl;
				cout<<"Press 5 for lab 5 report"<<endl;	
				cout<<"Press 6 for lab 6 report"<<endl;	
				cout<<"Press 7 for lab 7 report"<<endl;	
				cout<<"Press 8 for lab 8 report"<<endl;		
				cin>>option4;
				switch(option4)
				{
					case 1:
						cout<<endl;
				        cin>>lab1rep[i];
				        break;
				case 2:
					cout<<endl;
				        cin>>lab2rep[i];
				        break;
				case 3:
					cout<<endl;
				        cin>>lab3rep[i]; 
						break;       
				case 4:
					cout<<endl;
				        cin>>lab4rep[i];
				        break;
				case 5:
					cout<<endl;
				        cin>>lab5rep[i];
				        break;
				case 6:
					cout<<endl;
				        cin>>lab6rep[i];
				        break;
				case 7:
					cout<<endl;
				        cin>>lab7rep[i];
				        break;
				case 8:
					cout<<endl;
				        cin>>lab8rep[i];
				        break;				        
					
						}		
			j++;}}
			case 3:
				{
					cout<<"Enter mids marks :"<<endl;
					cin>>mids[i];
					break;
				}
			case 4:
			{
				cout<<"Enter final marks :"<<endl;
				cin>>final[i];
				break;
						}
			case 5:
			{
				cout<<"Enter CEA marks : "<<endl;
				cin>>CEA[i];
				break;
									}						
	 }                                  
    }
	file3<<"rollnum"<<","<<"name"<<","
         <<"lab1perf"<<","<<"lab2perf"<<","<<"lab3perf"<<","<<"lab4perf"<<","<<"lab5perf"<<","<<"lab6perf"<<","<<"lab7perf"<<","<<"lab8perf"<<","
         <<"lab1rep"<<","<<"lab2rep"<<","<<"lab3rep"<<","<<"lab4rep"<<","<<"lab5rep"<<","<<"lab6rep"<<","<<"lab7rep"<<","<<"lab8rep"<<","
         <<"mids"<<","
         <<"CEA"<<","
         <<"final"<<","<<"grades"<<"\n";  
	for(int j=0;j<size;j++)
	{
	file3.open("CE-112L BEEP II-A.csv",ios::out)	;
	file3<<rollnum[j]<<","<<name[j]<<","
         <<lab1perf[j]<<","<<lab2perf[j]<<","<<lab3perf[j]<<","<<lab4perf[j]<<","<<lab5perf[j]<<","<<lab6perf[j]<<","<<lab7perf[j]<<","<<lab8perf[j]<<","
         <<lab1rep[j]<<","<<lab2rep[j]<<","<<lab3rep[j]<<","<<lab4rep[j]<<","<<lab5rep[j]<<","<<lab6rep[j]<<","<<lab7rep[j]<<","<<lab8rep[j]<<","
         <<mids[j]<<","
         <<CEA[j]<<","
         <<final[j]<<","<<grade[j]<<"\n";       
}
	}  
	 


void data_beep_read()
{
string line;
file3.open("CE-112L BEEP II-A.csv",ios::in);
int i=0;
while (getline(file3, line)) 
{
    string rand;
    istringstream iss(line); 
    iss >> rollnum[i];
    getline(iss, rand, ',');
    getline(iss, name[i], ',');
    iss >> lab1perf[i];
    getline(iss, rand, ',');
    iss >> lab2perf[i];
    getline(iss, rand, ',');
    iss >> lab3perf[i];
    getline(iss, rand, ',');
    iss >> lab4perf[i];
    getline(iss, rand, ',');
    iss >> lab5perf[i];
    getline(iss, rand, ',');
    iss >> lab6perf[i];
    getline(iss, rand, ',');
    iss >> lab7perf[i];
    getline(iss, rand, ',');
    iss >> lab8perf[i];
    getline(iss, rand, ',');
    iss >>  lab1rep[i];
    getline(iss, rand, ',');
	iss >>  lab2rep[i];
	getline(iss, rand, ',');
	iss >>  lab3rep[i];
	getline(iss, rand, ',');
	iss >>  lab4rep[i];
	getline(iss, rand, ',');
	iss >>  lab5rep[i];
	getline(iss, rand, ',');
	iss >>  lab6rep[i];  
	getline(iss, rand, ',');
	iss >>  lab7rep[i];
	getline(iss, rand, ',');
	iss >>  lab8rep[i]; 
	getline(iss, rand, ',');
	iss >>  mids[i];
	getline(iss, rand, ',');
	iss >>  final[i];
	getline(iss, rand, ',');
	iss >>  CEA[i];	
    i++;
}
}

void set_beep_weightages()
{
    float total_weigh=100;
	float weigh;
	cout<<"Enter lab performance weightage : ";
	cin>>weigh_labperf;
	cout<<"Enter lab reports weightage : ";
	cin>>weigh_labrep;
	cout<<"Enter mids weightage : ";
	cin>>weigh_mids;
	cout<<"Enter finals weightage : ";
	cin>>weigh_final;
	cout<<"Enter CEA weightage : ";
	cin>>weigh_CEA;	
	weigh=weigh_labperf+weigh_labrep+weigh_mids+weigh_final+weigh_CEA;
	if (total_weigh==weigh)
	{
	cout<<"sum of total weightage : "<<weigh<<endl;
	}		
	else
	cout<<"Entered weightages are in correct"<<endl;			
}

void beep_total_marks()
{	
for(int i=0; i<=size ;i++)
{
total_labperf[i]=lab1perf[i]+lab2perf[i]+lab3perf[i]+lab4perf[i]+lab5perf[i]+lab6perf[i]+lab7perf[i]+lab8perf[i];
total_labrep[i]=lab1rep[i]+lab2rep[i]+lab3rep[i]+lab5rep[i]+lab5rep[i]+lab6rep[i]+lab7rep[i]+lab8rep[i];	
}
for(int j=0;j<size;j++)
{
total_marks[j]=((weigh_labperf*total_labperf[j])+(weigh_labrep*total_labrep[j])+(weigh_mids*mids[j])+(weigh_final*final[j])+(weigh_CEA*CEA[j]));
cout<<"total marks : "<<total_marks[j]<<endl;
}
}

void beep_grades()
{
	for(int i=0;i<5;i++)
	{
		if(total_marks[i]>=140 )
		{
		grade[i]='A';	
		}
		if(total_marks[i]<140&&total_marks[i]>=100)
		{
		grade[i]='B';	
		}
		if(total_marks[i]<100&&total_marks[i]>=80)
		{
		grade[i]='C';	
		}
		if(total_marks[i]<80&&total_marks[i]>=55)
		{
		grade[i]='D';	
		}
		if(total_marks[i]<55&&total_marks[i]>=45)
		{
		grade[i]='E';	
		}
		if(total_marks[i]<45)
		{
		grade[i]='F';	
		}
		  cout<<"grade : "<<grade[i]<<endl;
	}
	
	for(int j=0;j<size;j++)
	{
	file3.open("CE-112L BEEP II-A.csv",ios::out)	;
	file3<<rollnum[j]<<","<<name[j]<<","
         <<lab1perf[j]<<","<<lab2perf[j]<<","<<lab3perf[j]<<","<<lab4perf[j]<<","<<lab5perf[j]<<","<<lab6perf[j]<<","<<lab7perf[j]<<","<<lab8perf[j]<<","
         <<lab1rep[j]<<","<<lab2rep[j]<<","<<lab3rep[j]<<","<<lab4rep[j]<<","<<lab5rep[j]<<","<<lab6rep[j]<<","<<lab7rep[j]<<","<<lab8rep[j]<<","
         <<mids[j]<<","
         <<CEA[j]<<","
         <<final[j]<<","<<grade[j]<<"\n";	
	}
}

};

class BEBME : public teacherportal
{
	
public:
void data_bebme_entery(){
cout<<"Enter data in this sequence, Roll no. , Name , Labperformence , labreport , mid-term and finals : "<<endl;	
file4.open("CE-115L BEBME A.csv",ios::out | ios::app);	
 for (int i = 0; i < size; i++)
    {
        cout<<"Enter Student "<<i+1<<" data"<<endl;
        cout<<"Roll number: ";
        cin>>rollnum[i];
        cout<<"Name: ";
        cin>>name[i];
        cout<<"assesment marks"<<endl;
		cout<<"Press 1 for lab performance / 15"<<endl;
		cout<<"Press 2 for lab lab report /15"<<endl;
		cout<<"press 3 for Midterm /55"<<endl;
		cout<<"press 4 for CEA /20"<<endl;
		cout<<"press 5 for Final term /50"<<endl;
		cin>>option2;  
		switch(option2)
		{
			case 1:
				{ int j=0;
				while (j<5)
				{
				cout<<"Press 1 for lab 1 performance"<<endl;
				cout<<"Press 2 for lab 2 performance"<<endl;
				cout<<"Press 3 for lab 3 performance"<<endl;	
				cout<<"Press 4 for lab 4 performance"<<endl;
				cout<<"Press 5 for lab 5 performance"<<endl;
				cin>>option3;	
				switch(option3)
			   {
				 case 1:
				 		cout<<endl;
				        cin>>lab1perf[i];
				        break;
				case 2:
						cout<<endl;
				        cin>>lab2perf[i];
				        break;
				case 3:
						cout<<endl;
				        cin>>lab3perf[i];  
						break;      
				case 4:
						cout<<endl;
				        cin>>lab4perf[i];
				        break;
				case 5:
						cout<<endl;
				        cin>>lab5perf[i];
				        break; } j++;}	}			
						
			case 2:
			   { int j=0;
			   while(j<8)
			   {
			   
				cout<<"Press 1 for lab 1 report"<<endl;
				cout<<"Press 2 for lab 2 report"<<endl;
				cout<<"Press 3 for lab 3 report"<<endl;	
				cout<<"Press 4 for lab 4 report"<<endl;
				cout<<"Press 5 for lab 5 report"<<endl;	
				cout<<"Press 6 for lab 6 report"<<endl;	
				cout<<"Press 7 for lab 7 report"<<endl;	
				cout<<"Press 8 for lab 8 report"<<endl;						
				cin>>option4;
				switch(option4)
				{
					case 1:
						cout<<endl;
				        cin>>lab1rep[i];
				        break;
				case 2:
						cout<<endl;
				        cin>>lab2rep[i];
				        break;
				case 3:
						cout<<endl;
				        cin>>lab3rep[i]; 
						break;       
				case 4:
						cout<<endl;
				        cin>>lab4rep[i];
				        break;
				case 5:
						cout<<endl;
				        cin>>lab5rep[i];
				        break;
				case 6:
						cout<<endl;
				        cin>>lab6rep[i];
				        break;
				case 7:
						cout<<endl;
				        cin>>lab7rep[i];
				        break;
				case 8:
						cout<<endl;
				        cin>>lab8rep[i];
				        break;					
						}
						j++	;	
			}	}
			case 3:
				{
					cout<<"Enter mids marks :"<<endl;
					cin>>mids[i];
				
				}
			case 4:
			{
				cout<<"Enter final marks :"<<endl;
				cin>>final[i];
			
						}
			case 5:
			{
				cout<<"Enter CEA marks : "<<endl;
				cin>>CEA[i];
			
									}						
	 }                                  
    }
    	file4<<"rollnum"<<","<<"name"<<","
         <<"lab1perf"<<","<<"lab2perf"<<","<<"lab3perf"<<","<<"lab4perf"<<","<<"lab5perf"<<","
         <<"lab1rep"<<","<<"lab2rep"<<","<<"lab3rep"<<","<<"lab4rep"<<","<<"lab5rep"<<","<<"lab6rep"<<","<<"lab7rep"<<","<<"lab8rep"<<","
         <<"mids"<<","
         <<"CEA"<<","
         <<"final"<<","<<"grades"<<"\n";
 	for(int j=0;j<size;j++)
	{
	file4<<rollnum[j]<<","<<name[j]<<","
         <<lab1perf[j]<<","<<lab2perf[j]<<","<<lab3perf[j]<<","<<lab4perf[j]<<","<<lab5perf[j]<<","
         <<lab1rep[j]<<","<<lab2rep[j]<<","<<lab3rep[j]<<","<<lab4rep[j]<<","<<lab5rep[j]<<","<<lab6rep[j]<<","<<lab7rep[j]<<","<<lab8rep[j]<<","
         <<mids[j]<<","
         <<CEA[j]<<","
         <<final[j]<<"\n"; 
}	
	} 
	

void data_bebme_read()
{
string line;
file4.open("CE-115L BEBME A.csv",ios::in);
int i=0;
while (getline(file4, line)) 
{
    string rand;
    istringstream iss(line); 
    iss >> rollnum[i];
    getline(iss, rand, ',');
    getline(iss, name[i], ',');
    iss >> lab1perf[i];
    getline(iss, rand, ',');
    iss >> lab2perf[i];
    getline(iss, rand, ',');
    iss >> lab3perf[i];
    getline(iss, rand, ',');
    iss >> lab4perf[i];
    getline(iss, rand, ',');
    iss >> lab5perf[i];
    getline(iss, rand, ',');
    iss >> lab6perf[i];
    getline(iss, rand, ',');
    iss >>  lab1rep[i];
    getline(iss, rand, ',');
	iss >>  lab2rep[i];
	getline(iss, rand, ',');
	iss >>  lab3rep[i];
	getline(iss, rand, ',');
	iss >>  lab4rep[i];
	getline(iss, rand, ',');
	iss >>  lab5rep[i];
	getline(iss, rand, ',');
	iss >>  lab6rep[i];  
	getline(iss, rand, ',');
	iss >>  lab7rep[i];
	getline(iss, rand, ',');
	iss >>  lab8rep[i]; 
	getline(iss, rand, ',');
	iss >>  mids[i]; 
	getline(iss, rand, ',');
	iss >>  final[i];
	getline(iss, rand, ',');
	iss >>  CEA[i];	
    i++;
}
}

void set_bebme_weightages()
{
    float total_weigh=100;
	float weigh;

	cout<<"Enter lab performance weightage : ";
	cin>>weigh_labperf;
	cout<<"Enter lab reports weightage : ";
	cin>>weigh_labrep;
	cout<<"Enter mids weightage : ";
	cin>>weigh_mids;
	cout<<"Enter finals weightage : ";
	cin>>weigh_final;
	cout<<"Enter CEA weightage : ";
	cin>>weigh_CEA;	
	weigh=weigh_labperf+weigh_labrep+weigh_mids+weigh_final+weigh_CEA;
	if (total_weigh==weigh)
	{
	cout<<"sum of total weightage : "<<weigh<<endl;
	}		
	else
	cout<<"Entered weightages are incorrect"<<endl;			
}

void bebme_total_marks()
{	
for(int i=0; i<=size ;i++)
{
total_labperf[i]=lab1perf[i]+lab2perf[i]+lab3perf[i]+lab4perf[i]+lab5perf[i];
total_labrep[i]=lab1rep[i]+lab2rep[i]+lab3rep[i]+lab4rep[i]+lab5rep[i]+lab6rep[i]+lab7rep[i]+lab8rep[i];	
}
for(int j=0;j<size;j++)
{
total_marks[j]=((weigh_labperf/100)*total_labperf[j])+((weigh_labrep/100)*total_labrep[j])+((weigh_mids/100)*mids[j])+((weigh_final/100)*final[j])+((weigh_CEA/100)*CEA[j]);
cout<<endl;
cout<<"total marks : "<<total_marks[j]<<endl;

}
}

void bebme_grades()
{
	for(int i=0;i<size;i++)
	{
		if(total_marks[i]>=140 )
		{
		grade[i]='A';	
		}
		if(total_marks[i]<140&&total_marks[i]>=100)
		{
		grade[i]='B';	
		}
		if(total_marks[i]<100&&total_marks[i]>=80)
		{
		grade[i]='C';	
		}
		if(total_marks[i]<80&&total_marks[i]>=55)
		{
		grade[i]='D';	
		}
		if(total_marks[i]<55&&total_marks[i]>=45)
		{
		grade[i]='E';	
		}
		if(total_marks[i]<45)
		{
		grade[i]='F';	
		}
	  cout<<"grade : "<<grade[i]<<endl;	
	}
	file4.open("CE-115L BEBME A.csv",ios::out);
	for(int j=0;j<size;j++)
	{
	file4<<rollnum[j]<<","<<name[j]<<","
         <<lab1perf[j]<<","<<lab2perf[j]<<","<<lab3perf[j]<<","<<lab4perf[j]<<","<<lab5perf[j]<<","
         <<lab1rep[j]<<","<<lab2rep[j]<<","<<lab3rep[j]<<","<<lab4rep[j]<<","<<lab5rep[j]<<","<<lab6rep[j]<<","<<lab7rep[j]<<","<<lab8rep[j]<<","
         <<mids[j]<<","
         <<CEA[j]<<","
         <<final[j]<<","<<grade[j]<<"\n";	
	}
	
}

};

int main() {

game g1;
MTSB mtsb;
MTSA mtsa;
BEEP beep;
BEBME bme;

int option1,option2,option3,option4,option5,option6,option7,option8,option9,option10,option11,option12;

cout<<"Press 1 to Write the Data "<<endl;
cout<<"Press 2 to Read the Data "<<endl;
cout<<"Press 3 to skip "<<endl;
cout<<"Press 4 to visit cafe"<<endl;
cout<<"Press 5 to play tic-tac-toe game "<<endl;
cin>>option1;

switch(option1)
{
case 5:
{
char enter;
	int b;
	int y;
	int a;
	do{
cout<<"@@@@ WELCOME TO DIGITAL GAMING ( TIC TAC TOE ) WORLD @@@@ "<<endl;
cout<<" "<<endl;
cout<<"***THANKS FOR CHOOSING OUR GAME***"<<endl;
cout<<" "<<endl;
cout<<"Press 1 to play game "<<endl;
cout<<" "<<endl;
cout<<"Press 2 to Exit(not to start yet) game"<<endl;
cout<<" "<<endl;
cin>>a;
switch(a){
case 1:
cout<<"%%% TIC TOC TOE GAME %%%"<<endl;
cout<<" "<<endl;
cout<<"PLAYER - X ### VERSES ### PLAYER - O"<<endl;
cout<<" "<<endl;
cout<<"Both palyers have 9 moves so do ur entry carefully"<<endl;
cout<<"NOTE = *if u want to win ,enter ur marks in dignol or in straight line "<<endl;
cout<<"!!! START !!!"<<endl;
cout<<" "<<endl;
cout<<"players are requested to enjoy thier turn one by one and follow the instructions of the system "	<<endl;
cout<<" "<<endl;

    g1.Draw() ; //calling function	

   for(int i=0;i<9;i++)
    {
    	cout<<"TURN = "<<" - player - "<<g1.getplayer()<<endl;
        g1.posibility();
        g1.Draw();
        
        if (g1.Win() == 'X')
        {
            cout << "***.... X wins! ***" << endl;
            break;
        }
        else if (g1.Win() == 'O')
        {
            cout << "***.... O wins! ***" << endl;
            break;
        }
        
        g1.Playerturn();
       
}
if (g1.Win()=='X'||g1.Win()=='O')

{
    
    cout << "\t--------------------------------------------"<< "\n\t|                                          |"<< endl;
	cout << "\t|******************************************|"<< "\n\t|                                          |"<< endl;
	cout << "\t|                                          |"<< "\n\t|          ** CONGRATULATIONS! **          |" << endl;
	cout << "\t|            PLAYER " << g1.getplayer() << " WINS!!!              |                                          " << endl; 
	cout << "\t|                                          |"<< "\n\t|                                          |"<< endl;
	cout << "\t|                                          |"<< "\n\t|                                          |"<< endl;
	cout << "\t|******************************************|"<< "\n\t--------------------------------------------"<< endl;}
	else
	cout<<"***Game Draws between two players***No one wins...better "<<endl;

break;
case 2:
cout<<"You message system not to start game now :("<<endl;
break;
}
//cout<<"***PLAY AGAIN***"<<endl;
cout<<" "<<endl;
cout<<"keeping previous positions and steps in mind"<<endl;//part of brain stroming
cout<<"Input 'y' to start a New game"<<endl;
cout<<" "<<endl;
cout<<"Enter any integer to exit game"<<endl;
cout<<" "<<endl;
cin>>enter;
g1.resetGame();
g1.clearboard();

}while (enter=='y'||enter=='Y');
cout<<"^^^^^^ Exit game ^^^^^^"<<endl;
cout<<" "<<endl;
cout<<"***Plz Chose our system again *** "<<endl;

}
case 4:
{
cout<<"Press 1 to view menu and order: "<<endl;
cout<<"Press 2 to exit: "<<endl;
cin>>option9;
switch(option9){
case 1:
a.menu();
a.select();
break;
case 2:
break;
}
}
case 1:
{
cout<<endl;	
cout<<"Press 1 for CE-112L MTS II B"<<endl;
cout<<"Press 2 for CE-112L MTS II-A"<<endl;
cout<<"press 3 for CE-112L BEEP II-A"<<endl;
cout<<"press 4 for CE-115L BEBME A"	<<endl;
cout<<"press 5 to skip entry"<<endl;
cin>>option2;
switch(option2)
{
case 1:
	mtsb.data_mtsb_entery();
	break;
case 2:
	mtsa.data_mtsa_entery();
	break;
case 3:
	beep.data_beep_entery();
	break;
case 4:
	bme.data_bebme_entery();
	break;
case 5:
    cout<<"NO ENTERIES ARE DONE "<<endl;				
}
}
break;

case 2:
{
cout<<"Press 1 for CE-112L MTS II B"<<endl;
cout<<"Press 2 for CE-112L MTS II-A"<<endl;
cout<<"press 3 for CE-112L BEEP II-A"<<endl;
cout<<"press 4 for CE-115L BEBME A"	<<endl;
cout<<"press 5 to skip reading"<<endl;
cin>>option2;
switch(option2)
{
case 1:
	mtsb.data_mtsb_read();

case 2:
	mtsa.data_mtsa_read();

case 3:
	beep.data_beep_read();

case 4:
	bme.data_bebme_read();

case 5:
    cout<<"NOTHING TO READ "<<endl;				
}	
}

case 3:
{
cout<<endl;	
cout<<"SKIPPED"<<endl;
}	

}
cout<<"After writing press 1 to read "<<endl;
cout<<"press 2 to skip"<<endl;
cin>>option11;
switch(option11)
{
case 1:
{	
cout<<"Press 1 for CE-112L MTS II B"<<endl;
cout<<"Press 2 for CE-112L MTS II-A"<<endl;
cout<<"press 3 for CE-112L BEEP II-A"<<endl;
cout<<"press 4 for CE-115L BEBME A"	<<endl;
cout<<"press 5 to skip reading"<<endl;
cin>>option2;
switch(option2)
{
case 1:
	mtsb.data_mtsb_read();
	break;
case 2:
	mtsa.data_mtsa_read();
	break;
case 3:
	beep.data_beep_read();
	break;
case 4:
	bme.data_bebme_read();
	break;
case 5:
    cout<<"NOTHING TO READ "<<endl;				
}
}
break;
}

cout<<"Press 1 to set weightage " <<endl;
cout<<"Press 2 to skip  " <<endl;
cin>>option3;
switch(option3)
{
case 1:
{
cout<<"Press 1 for CE-112L MTS II B"<<endl;
cout<<"Press 2 for CE-112L MTS II-A"<<endl;
cout<<"press 3 for CE-112L BEEP II-A"<<endl;
cout<<"press 4 for CE-115L BEBME A"	<<endl;
cout<<"press 5 to skip set weightages "<<endl;
cin>>option4;
switch(option4)
{
case 1:
	mtsb.set_mtsb_weightages();
	break;
case 2:
	mtsa.set_mtsa_weightages();
	break;
case 3:
	beep.set_beep_weightages();
	break;
case 4:
	bme.set_bebme_weightages();
	break;
case 5:
    cout<<"WEIGHTAGES NOT TO SET"<<endl;	
}	
}
break;
case 2:
{
cout<<endl;
cout<<"SKIPPED"<<endl;		
}
	
}
cout<<endl;
cout<<"Press 1 to Total the marks " <<endl;
cout<<"Press 2 to skip  " <<endl;
cin>>option5;
switch(option5)
{
case 1:
{
cout<<"Press 1 for CE-112L MTS II B"<<endl;
cout<<"Press 2 for CE-112L MTS II-A"<<endl;
cout<<"press 3 for CE-112L BEEP II-A"<<endl;
cout<<"press 4 for CE-115L BEBME A"	<<endl;
cout<<"press 5 to skip the total marks "<<endl;
cin>>option6;
switch(option6)
{
case 1:
	mtsb.mtsb_total_marks();
	break;
case 2:
	mtsa.mtsa_total_marks();
	break;
case 3:
	beep.beep_total_marks();
	break;
case 4:
	bme.bebme_total_marks();
	break;
case 5:
    cout<<"NO TOTAL MARKS "<<endl;	
}	
}
break;
case 2:
{
cout<<endl;
cout<<"SKIPPED"<<endl;	
}	
	
}

cout<<"Press 1 to allot the grades "<<endl;
cout<<"Press 2 to skip"<<endl;
cin>>option7;
switch(option7)
{
case 1:
{	
cout<<"Press 1 for CE-112L MTS II B"<<endl;
cout<<"Press 2 for CE-112L MTS II-A"<<endl;
cout<<"press 3 for CE-112L BEEP II-A"<<endl;
cout<<"press 4 for CE-115L BEBME A"	<<endl;
cout<<"press 5 to skip the grades "<<endl;
cin>>option8;
switch(option8)
{
case 1:
	mtsb.mtsb_grades();
	break;
case 2:
	mtsa.mtsa_grades();
	break;
case 3:
	beep.beep_grades();
	break;
case 4:
	bme.bebme_grades();
	break;
case 5:
    cout<<"NO GRADES "<<endl;
}
}
break;
case 2:
{
cout<<endl;
cout<<"SKIPPED"<<endl;	
	}	
}


	return 0;
}







